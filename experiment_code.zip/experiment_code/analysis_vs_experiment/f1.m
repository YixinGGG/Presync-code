function F1=f1(x,y,z)
    m=6000;
    b=2000;
    F1=x*(b/m*y+(m-b)/m)^z;
end