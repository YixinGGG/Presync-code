function F2=f2(x,y,z)
    m=6000;
    b=2000;
    F2=x*((b/m*y+(m-b)/m)^z-((m-b)/m)^z)/(1-((m-b)/m)^z);
end